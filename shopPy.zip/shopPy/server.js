const express = require('express');
const multer = require('multer');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;

// Статика
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());

// Настройка multer для загрузки фото
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});
const upload = multer({ storage });

// База данных SQLite
const db = new sqlite3.Database('database.db');
db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        manufacturer TEXT,
        release_date TEXT,
        weight REAL,
        price REAL,
        photo TEXT
    )`);
});

// --- API --- //

// Получить все товары или по поиску
app.get('/api/products', (req, res) => {
    const search = req.query.search || '';
    db.all(`SELECT * FROM products WHERE name LIKE ? OR manufacturer LIKE ? ORDER BY id DESC`,
        [`%${search}%`, `%${search}%`],
        (err, rows) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json(rows);
        }
    );
});

// Добавить товар
app.post('/api/products', upload.single('photo'), (req, res) => {
    const { name, manufacturer, release_date, weight, price, photo_url } = req.body;
    let photo = photo_url || null;
    if (req.file) photo = '/uploads/' + req.file.filename;

    db.run(`INSERT INTO products (name, manufacturer, release_date, weight, price, photo)
            VALUES (?, ?, ?, ?, ?, ?)`,
        [name, manufacturer, release_date, weight, price, photo],
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ id: this.lastID });
        }
    );
});

// Удалить товар
app.delete('/api/products/:id', (req, res) => {
    const id = req.params.id;
    db.run(`DELETE FROM products WHERE id = ?`, [id], function(err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ deleted: this.changes });
    });
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
