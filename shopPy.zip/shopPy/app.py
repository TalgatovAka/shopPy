import os
import re
import json
from flask import (
    Flask, render_template, request, redirect, session,
    jsonify, send_from_directory, url_for, make_response
)
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = "CHANGE_THIS_SECRET"  # поменяй на своё в проде

# Файлы и папки
DB_FILE = "products.json"
UPLOAD_FOLDER = os.path.join("static", "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
if not os.path.exists(DB_FILE):
    with open(DB_FILE, "w", encoding="utf-8") as f:
        json.dump([], f)

# ------------------------
# Пользователи в памяти
# ------------------------
# Поля: login, email, password
users = [
    {"login": "admin", "email": "admin@example.com", "password": "12345"},
    {"login": "aka",   "email": "aka@example.com",   "password": "tal"}
]

# ------------------------
# Переводы (ключи используются в шаблонах)
# ------------------------
translations = {
    "ru": {
        "store": "Магазин",
        "add_product": "Добавить товар",
        "search": "Поиск товара...",
        "manufacturer": "Производитель",
        "release": "Дата выпуска",
        "weight": "Вес",
        "price": "Цена",
        "edit": "Редактировать",
        "delete": "Удалить",
        "login": "Логин",
        "email": "Email",
        "password": "Пароль",
        "btn_login": "Войти",
        "btn_register": "Регистрация",
        "btn_logout": "Выйти",
        "register_title": "Регистрация",
        "login_title": "Вход",
        "name": "Название",
        "photo": "Фото",
        "submit": "Отправить",
        "save": "Сохранить",
        "back": "Назад",
        "add_page": "Добавить товар",
        "edit_page": "Редактирование товара",
        "login_or_email": "Логин или Email",
        "invalid_credentials": "Неверный логин или пароль",
        "register_success": "Регистрация успешна. Войдите.",
        "invalid_login_chars": "Логин может содержать только латиницу, цифры и знак _",
        "invalid_email": "Неправильный email",
        "user_exists": "Пользователь с таким логином или email уже существует",
        "confirm_delete": "Удалить товар?",
        "lang": "Язык"
    },
    "kk": {
        "store": "Дүкен",
        "add_product": "Тауар қосу",
        "search": "Тауар іздеу...",
        "manufacturer": "Өндіруші",
        "release": "Шығарылған күні",
        "weight": "Салмағы",
        "price": "Бағасы",
        "edit": "Өңдеу",
        "delete": "Жою",
        "login": "Логин",
        "email": "Email",
        "password": "Құпия сөз",
        "btn_login": "Кіру",
        "btn_register": "Тіркелу",
        "btn_logout": "Шығу",
        "register_title": "Тіркелу",
        "login_title": "Кіру",
        "name": "Атау",
        "photo": "Сурет",
        "submit": "Жіберу",
        "save": "Сақтау",
        "back": "Артқа",
        "add_page": "Тауар қосу",
        "edit_page": "Тауарды өңдеу",
        "login_or_email": "Логин немесе Email",
        "invalid_credentials": "Логин немесе құпия сөз қате",
        "register_success": "Тіркелу сәтті өтті. Кіру жасаңыз.",
        "invalid_login_chars": "Логинде тек латын әріптер, цифрлар және _ болуы тиіс",
        "invalid_email": "Қате email",
        "user_exists": "Осы логин немесе email бар қолданушы бар",
        "confirm_delete": "Тауарды жою?",
        "lang": "Тіл"
    },
    "en": {
        "store": "Store",
        "add_product": "Add product",
        "search": "Search product...",
        "manufacturer": "Manufacturer",
        "release": "Release date",
        "weight": "Weight",
        "price": "Price",
        "edit": "Edit",
        "delete": "Delete",
        "login": "Login",
        "email": "Email",
        "password": "Password",
        "btn_login": "Sign in",
        "btn_register": "Register",
        "btn_logout": "Logout",
        "register_title": "Register",
        "login_title": "Login",
        "name": "Name",
        "photo": "Photo",
        "submit": "Submit",
        "save": "Save",
        "back": "Back",
        "add_page": "Add product",
        "edit_page": "Edit product",
        "login_or_email": "Login or Email",
        "invalid_credentials": "Wrong login or password",
        "register_success": "Registered. Please sign in.",
        "invalid_login_chars": "Login may contain only latin letters, numbers and _",
        "invalid_email": "Invalid email",
        "user_exists": "User with this login or email already exists",
        "confirm_delete": "Delete this product?",
        "lang": "Language"
    }
}

# ------------------------
# Помощники перевода
# ------------------------
from flask import request
def t(key):
    lang = session.get("lang", "ru")
    return translations.get(lang, translations["ru"]).get(key, key)

@app.context_processor
def inject_t():
    return dict(t=t)

@app.route("/lang/<lng>")
def set_lang(lng):
    if lng not in translations:
        lng = "ru"
    session["lang"] = lng
    return redirect(request.referrer or url_for("products_page"))

# ------------------------
# Работа с товарами
# ------------------------
def load_products():
    with open(DB_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_products(data):
    with open(DB_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def is_logged():
    return "user" in session

# ------------------------
# Валидация для регистрации
# ------------------------
LOGIN_RE = re.compile(r'^[A-Za-z0-9_]{3,30}$')
EMAIL_RE = re.compile(r'^[^@]+@[^@]+\.[^@]+$')

def find_user_by_login_or_email(value):
    for u in users:
        if u.get("login") == value or u.get("email") == value:
            return u
    return None

# ------------------------
# Роути
# ------------------------
@app.route("/")
def index():
    return redirect(url_for("products_page"))

@app.route("/products")
def products_page():
    prods = load_products()
    return render_template("products.html", products=prods, logged=is_logged(), user=session.get("user"))

@app.route("/product_image/<filename>")
def product_image(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

# Register
@app.route("/register", methods=["GET", "POST"])
def register_page():
    if request.method == "POST":
        login = request.form.get("login", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "").strip()

        # валидация
        if not LOGIN_RE.match(login):
            return render_template("register.html", error=t("invalid_login_chars"))
        if not EMAIL_RE.match(email):
            return render_template("register.html", error=t("invalid_email"))
        # существующий
        for u in users:
            if u["login"] == login or u["email"] == email:
                return render_template("register.html", error=t("user_exists"))

        users.append({"login": login, "email": email, "password": password})
        return render_template("login.html", info=t("register_success"))
    return render_template("register.html")

# Login
@app.route("/login", methods=["GET", "POST"])
def login_page():
    if request.method == "POST":
        login_or_email = request.form.get("login_or_email", "").strip()
        password = request.form.get("password", "").strip()

        user = None
        # найдем по логину или email
        for u in users:
            if u["login"] == login_or_email or u["email"] == login_or_email:
                user = u
                break

        if user and user["password"] == password:
            session["user"] = user["login"]
            return redirect(url_for("add_page"))
        return render_template("login.html", error=t("invalid_credentials"))
    return render_template("login.html")

# Logout
@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("products_page"))

# Add page protected
@app.route("/add", methods=["GET"])
def add_page():
    if not is_logged():
        return redirect(url_for("login_page"))
    return render_template("add.html", logged=True, user=session.get("user"))

@app.route("/add_product", methods=["POST"])
def add_product():
    if not is_logged():
        return jsonify({"error": "not authorized"}), 401

    data = load_products()
    new_id = (data[-1]["id"] + 1) if data else 1

    name = request.form.get("name", "").strip()
    brand = request.form.get("brand", "").strip()
    release = request.form.get("release", "").strip()
    weight = request.form.get("weight", "").strip()
    price = request.form.get("price", "").strip()

    image_filename = ""
    file = request.files.get("image")
    if file and file.filename:
        filename = secure_filename(file.filename)
        # unique filename
        filename = f"{new_id}_{filename}"
        file.save(os.path.join(UPLOAD_FOLDER, filename))
        image_filename = filename

    product = {
        "id": new_id,
        "name": name,
        "brand": brand,
        "release": release,
        "weight": weight,
        "price": price,
        "image": image_filename
    }
    data.append(product)
    save_products(data)
    return jsonify({"ok": True})

# Edit product (get page)
@app.route("/edit/<int:product_id>", methods=["GET"])
def edit_page(product_id):
    if not is_logged():
        return redirect(url_for("login_page"))
    data = load_products()
    product = next((p for p in data if p["id"] == product_id), None)
    if not product:
        return "Not found", 404
    return render_template("edit.html", product=product)

# Update product (POST)
@app.route("/update", methods=["POST"])
def update_product():
    if not is_logged():
        return jsonify({"error": "not authorized"}), 401

    data = load_products()
    try:
        product_id = int(request.form.get("id"))
    except:
        return jsonify({"error": "invalid id"}), 400

    for i, p in enumerate(data):
        if p["id"] == product_id:
            name = request.form.get("name", "").strip()
            brand = request.form.get("brand", "").strip()
            release = request.form.get("release", "").strip()
            weight = request.form.get("weight", "").strip()
            price = request.form.get("price", "").strip()

            filename = p.get("image", "")
            file = request.files.get("image")
            if file and file.filename:
                fname = secure_filename(file.filename)
                fname = f"{product_id}_{fname}"
                file.save(os.path.join(UPLOAD_FOLDER, fname))
                filename = fname

            data[i] = {
                "id": product_id,
                "name": name,
                "brand": brand,
                "release": release,
                "weight": weight,
                "price": price,
                "image": filename
            }
            save_products(data)
            return jsonify({"ok": True})
    return jsonify({"error": "not found"}), 404

# Delete product
@app.route("/delete/<int:product_id>", methods=["DELETE"])
def delete_product(product_id):
    if not is_logged():
        return jsonify({"error": "not authorized"}), 401
    data = load_products()
    new = [p for p in data if p["id"] != product_id]
    save_products(new)
    return jsonify({"ok": True})

# API list
@app.route("/list")
def api_list():
    return jsonify(load_products())

# serve uploaded images handled via /product_image/<filename>

if __name__ == "__main__":
    app.run(debug=True)
