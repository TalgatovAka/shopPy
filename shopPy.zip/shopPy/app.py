import os
import json
from flask import Flask, render_template, request, jsonify, send_from_directory, redirect, url_for

app = Flask(__name__)
UPLOAD_FOLDER = "static/uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
DATA_FILE = "products.json"

def load_data():
    if not os.path.exists(DATA_FILE):
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump([], f, ensure_ascii=False, indent=4)
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_data(data):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

# делаем главную доступной по / и /products
@app.route("/")
def root():
    return redirect(url_for("products_page"))

@app.route("/products")
def products_page():
    data = load_data()
    return render_template("products.html", products=data)

@app.route("/add")
def add_page():
    return render_template("add.html")

@app.route("/edit/<int:product_id>")
def edit_page(product_id):
    data = load_data()
    product = next((p for p in data if p["id"] == product_id), None)
    if not product:
        return "Товар не найден", 404
    return render_template("edit.html", product=product)

# загрузка изображения (используется при добавлении/редактировании через форму JS или form-data)
@app.route("/upload_image", methods=["POST"])
def upload_image():
    if "image" not in request.files:
        return jsonify({"error": "no file"}), 400
    file = request.files["image"]
    filename = f"{int(os.times().system*1000)}_{file.filename}"
    path = os.path.join(UPLOAD_FOLDER, filename)
    file.save(path)
    return jsonify({"filename": filename})

# добавление товара (form-data)
@app.route("/add_product", methods=["POST"])
def add_product():
    data = load_data()
    new_id = (data[-1]["id"] + 1) if data else 1

    name = request.form.get("name", "").strip()
    brand = request.form.get("brand", "").strip()
    release = request.form.get("release", "").strip()
    weight = request.form.get("weight", "").strip()
    price = request.form.get("price", "").strip()

    filename = ""
    img = request.files.get("image")
    if img and img.filename:
        filename = f"{new_id}_{img.filename}"
        img.save(os.path.join(UPLOAD_FOLDER, filename))

    product = {
        "id": new_id,
        "name": name,
        "brand": brand,
        "release": release,
        "weight": weight,
        "price": price,
        "image": filename
    }
    data.append(product)
    save_data(data)
    return jsonify({"status": "ok", "id": new_id})

# обновление товара (form-data)
@app.route("/update", methods=["POST"])
def update_product():
    data = load_data()
    try:
        product_id = int(request.form.get("id"))
    except:
        return jsonify({"error": "invalid id"}), 400

    for i, p in enumerate(data):
        if p["id"] == product_id:
            # если загрузили новое изображение
            img = request.files.get("image")
            filename = p.get("image", "")
            if img and img.filename:
                filename = f"{product_id}_{img.filename}"
                img.save(os.path.join(UPLOAD_FOLDER, filename))

            data[i] = {
                "id": product_id,
                "name": request.form.get("name", "").strip(),
                "brand": request.form.get("brand", "").strip(),
                "release": request.form.get("release", "").strip(),
                "weight": request.form.get("weight", "").strip(),
                "price": request.form.get("price", "").strip(),
                "image": filename
            }
            save_data(data)
            return jsonify({"status": "updated"})
    return jsonify({"error": "not found"}), 404

# получить список (JSON) — можно использовать fetch("/list")
@app.route("/list")
def list_products():
    return jsonify(load_data())

# удаление товара по DELETE /delete/<id>
@app.route("/delete/<int:product_id>", methods=["DELETE"])
def delete_product(product_id):
    data = load_data()
    new = [p for p in data if p["id"] != product_id]
    save_data(new)
    return jsonify({"status": "deleted"})

# отдача изображений (обычно Flask статик сам отдаёт /static, но на всякий случай)
@app.route("/static/uploads/<path:filename>")
def uploaded_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

if __name__ == "__main__":
    app.run(debug=True)
