import os
import re
import sqlite3
import unicodedata
from flask import (
    Flask, render_template, request, redirect, session,
    jsonify, send_from_directory, url_for
)
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "CHANGE_THIS_SECRET"  # поменяй в проде

UPLOAD_FOLDER = os.path.join("static", "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

DB_FILE = "database.db"

# ------------------------
# Инициализация базы
# ------------------------
def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    # Таблица пользователей
    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            login TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    """)
    # Таблица товаров
    c.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            brand TEXT,
            release TEXT,
            weight TEXT,
            price TEXT,
            image TEXT
        )
    """)
    conn.commit()
    conn.close()

init_db()

# ------------------------
# Переводы
# ------------------------
translations = {
    "ru": {
        "store": "Магазин",
        "add_product": "Добавить товар",
        "search": "Поиск товара...",
        "manufacturer": "Производитель",
        "release": "Дата выпуска",
        "weight": "Вес",
        "price": "Цена",
        "edit": "Редактировать",
        "delete": "Удалить",
        "login": "Логин",
        "email": "Email",
        "password": "Пароль",
        "btn_login": "Войти",
        "btn_register": "Регистрация",
        "btn_logout": "Выйти",
        "register_title": "Регистрация",
        "login_title": "Вход",
        "name": "Название",
        "photo": "Фото",
        "submit": "Отправить",
        "save": "Сохранить",
        "back": "Назад",
        "add_page": "Добавить товар",
        "edit_page": "Редактирование товара",
        "login_or_email": "Логин или Email",
        "invalid_credentials": "Неверный логин или пароль",
        "register_success": "Регистрация успешна. Войдите.",
        "invalid_login_chars": "Логин может содержать только латиницу, цифры и знак _",
        "invalid_email": "Неправильный email",
        "user_exists": "Пользователь с таким логином или email уже существует",
        "confirm_delete": "Удалить товар?",
        "lang": "Язык"
    },
    "kk": {
        "store": "Дүкен",
        "add_product": "Тауар қосу",
        "search": "Тауар іздеу...",
        "manufacturer": "Өндіруші",
        "release": "Шығарылған күні",
        "weight": "Салмағы",
        "price": "Бағасы",
        "edit": "Өңдеу",
        "delete": "Жою",
        "login": "Логин",
        "email": "Email",
        "password": "Құпия сөз",
        "btn_login": "Кіру",
        "btn_register": "Тіркелу",
        "btn_logout": "Шығу",
        "register_title": "Тіркелу",
        "login_title": "Кіру",
        "name": "Атау",
        "photo": "Сурет",
        "submit": "Жіберу",
        "save": "Сақтау",
        "back": "Артқа",
        "add_page": "Тауар қосу",
        "edit_page": "Тауарды өңдеу",
        "login_or_email": "Логин немесе Email",
        "invalid_credentials": "Логин немесе құпия сөз қате",
        "register_success": "Тіркелу сәтті өтті. Кіру жасаңыз.",
        "invalid_login_chars": "Логинде тек латын әріптер, цифрлар және _ болуы тиіс",
        "invalid_email": "Қате email",
        "user_exists": "Осы логин немесе email бар қолданушы бар",
        "confirm_delete": "Тауарды жою?",
        "lang": "Тіл"
    },
    "en": {
        "store": "Store",
        "add_product": "Add product",
        "search": "Search product...",
        "manufacturer": "Manufacturer",
        "release": "Release date",
        "weight": "Weight",
        "price": "Price",
        "edit": "Edit",
        "delete": "Delete",
        "login": "Login",
        "email": "Email",
        "password": "Password",
        "btn_login": "Sign in",
        "btn_register": "Register",
        "btn_logout": "Logout",
        "register_title": "Register",
        "login_title": "Login",
        "name": "Name",
        "photo": "Photo",
        "submit": "Submit",
        "save": "Save",
        "back": "Back",
        "add_page": "Add product",
        "edit_page": "Edit product",
        "login_or_email": "Login or Email",
        "invalid_credentials": "Wrong login or password",
        "register_success": "Registered. Please sign in.",
        "invalid_login_chars": "Login may contain only latin letters, numbers and _",
        "invalid_email": "Invalid email",
        "user_exists": "User with this login or email already exists",
        "confirm_delete": "Delete this product?",
        "lang": "Language"
    }
}

# ------------------------
# Помощники перевода
# ------------------------
def t(key):
    lang = session.get("lang", "ru")
    return translations.get(lang, translations["ru"]).get(key, key)

@app.context_processor
def inject_t():
    return dict(t=t)

@app.route("/lang/<lng>")
def set_lang(lng):
    if lng not in translations:
        lng = "ru"
    session["lang"] = lng
    return redirect(request.referrer or url_for("products_page"))

# ------------------------
# Вспомогательные функции БД
# ------------------------
def get_db_connection():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

def find_user_by_login_or_email(value):
    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE login=? OR email=?", (value, value)).fetchone()
    conn.close()
    return user

def load_products():
    conn = get_db_connection()
    products = conn.execute("SELECT * FROM products").fetchall()
    conn.close()
    return [dict(p) for p in products]

def save_product(product):
    conn = get_db_connection()
    if "id" in product:
        conn.execute("""
            UPDATE products SET name=?, brand=?, release=?, weight=?, price=?, image=? WHERE id=?
        """, (product["name"], product["brand"], product["release"], product["weight"], product["price"], product["image"], product["id"]))
    else:
        cur = conn.execute("""
            INSERT INTO products (name, brand, release, weight, price, image) VALUES (?, ?, ?, ?, ?, ?)
        """, (product["name"], product["brand"], product["release"], product["weight"], product["price"], product["image"]))
        product["id"] = cur.lastrowid
    conn.commit()
    conn.close()
    return product.get("id")

def delete_product_by_id(product_id):
    conn = get_db_connection()
    conn.execute("DELETE FROM products WHERE id=?", (product_id,))
    conn.commit()
    conn.close()

def is_logged():
    return "user" in session

# ------------------------
# Валидация
# ------------------------
LOGIN_RE = re.compile(r'^[A-Za-z0-9_]{3,30}$')
EMAIL_RE = re.compile(r'^[^@]+@[^@]+\.[^@]+$')

# ------------------------
# Безопасное имя файла
# ------------------------
def slugify(value):
    value = unicodedata.normalize('NFKD', value).encode('ascii', 'ignore').decode('ascii')
    value = re.sub(r'[^\w\s-]', '', value).strip().lower()
    value = re.sub(r'[-\s]+', '_', value)
    return value

# ------------------------
# Роути
# ------------------------
@app.route("/")
def index():
    return redirect(url_for("products_page"))

@app.route("/products")
def products_page():
    prods = load_products()
    return render_template("products.html", products=prods, logged=is_logged(), user=session.get("user"))

@app.route("/product_image/<filename>")
def product_image(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

# Register
@app.route("/register", methods=["GET", "POST"])
def register_page():
    if request.method == "POST":
        login = request.form.get("login", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "").strip()

        if not LOGIN_RE.match(login):
            return render_template("register.html", error=t("invalid_login_chars"))
        if not EMAIL_RE.match(email):
            return render_template("register.html", error=t("invalid_email"))
        if find_user_by_login_or_email(login) or find_user_by_login_or_email(email):
            return render_template("register.html", error=t("user_exists"))

        hashed_password = generate_password_hash(password)
        conn = get_db_connection()
        conn.execute("INSERT INTO users (login, email, password) VALUES (?, ?, ?)", (login, email, hashed_password))
        conn.commit()
        conn.close()
        return render_template("login.html", info=t("register_success"))
    return render_template("register.html")

# Login
@app.route("/login", methods=["GET", "POST"])
def login_page():
    if request.method == "POST":
        login_or_email = request.form.get("login_or_email", "").strip()
        password = request.form.get("password", "").strip()
        user = find_user_by_login_or_email(login_or_email)
        if user and check_password_hash(user["password"], password):
            session["user"] = user["login"]
            return redirect(url_for("add_page"))
        return render_template("login.html", error=t("invalid_credentials"))
    return render_template("login.html")

# Logout
@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("products_page"))

# Add page
@app.route("/add", methods=["GET"])
def add_page():
    if not is_logged():
        return redirect(url_for("login_page"))
    return render_template("add.html", logged=True, user=session.get("user"))

# Add product
@app.route("/add_product", methods=["POST"])
def add_product():
    if not is_logged():
        return jsonify({"error": "not authorized"}), 401

    name = request.form.get("name", "").strip()
    brand = request.form.get("brand", "").strip()
    release = request.form.get("release", "").strip()
    weight = request.form.get("weight", "").strip()
    price = request.form.get("price", "").strip()

    image_filename = ""
    file = request.files.get("image")

    # Сначала вставляем без image, чтобы получить id
    product_id = save_product({
        "name": name,
        "brand": brand,
        "release": release,
        "weight": weight,
        "price": price,
        "image": ""
    })

    if file and file.filename:
        ext = os.path.splitext(file.filename)[1]
        safe_name = slugify(name)
        image_filename = f"{product_id}_{safe_name}{ext}"
        file.save(os.path.join(UPLOAD_FOLDER, image_filename))
        # Обновим запись с image
        save_product({
            "id": product_id,
            "name": name,
            "brand": brand,
            "release": release,
            "weight": weight,
            "price": price,
            "image": image_filename
        })

    return jsonify({"ok": True})

# Edit product page
@app.route("/edit/<int:product_id>", methods=["GET"])
def edit_page(product_id):
    if not is_logged():
        return redirect(url_for("login_page"))
    products = load_products()
    product = next((p for p in products if p["id"] == product_id), None)
    if not product:
        return "Not found", 404
    return render_template("edit.html", product=product)

# Update product
@app.route("/update", methods=["POST"])
def update_product():
    if not is_logged():
        return jsonify({"error": "not authorized"}), 401

    try:
        product_id = int(request.form.get("id"))
    except:
        return jsonify({"error": "invalid id"}), 400

    products = load_products()
    product = next((p for p in products if p["id"] == product_id), None)
    if not product:
        return jsonify({"error": "not found"}), 404

    name = request.form.get("name", "").strip()
    brand = request.form.get("brand", "").strip()
    release = request.form.get("release", "").strip()
    weight = request.form.get("weight", "").strip()
    price = request.form.get("price", "").strip()

    filename = product.get("image", "")
    file = request.files.get("image")
    if file and file.filename:
        ext = os.path.splitext(file.filename)[1]
        safe_name = slugify(name)
        fname = f"{product_id}_{safe_name}{ext}"
        file.save(os.path.join(UPLOAD_FOLDER, fname))
        filename = fname

    save_product({
        "id": product_id,
        "name": name,
        "brand": brand,
        "release": release,
        "weight": weight,
        "price": price,
        "image": filename
    })
    return jsonify({"ok": True})

# Delete product
@app.route("/delete/<int:product_id>", methods=["DELETE"])
def delete_product_route(product_id):
    if not is_logged():
        return jsonify({"error": "not authorized"}), 401
    delete_product_by_id(product_id)
    return jsonify({"ok": True})

# API list
@app.route("/list")
def api_list():
    return jsonify(load_products())

if __name__ == "__main__":
    app.run(debug=True)
