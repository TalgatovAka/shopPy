document.addEventListener('DOMContentLoaded', function(){
  const btn = document.getElementById('langBtn');
  const menu = document.getElementById('langMenu');
  if (!btn || !menu) return;
  btn.addEventListener('click', (e)=>{
    e.preventDefault();
    menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
  });
  document.addEventListener('click', (e)=>{
    if (!btn.contains(e.target) && !menu.contains(e.target)) menu.style.display = 'none';
  });
});
