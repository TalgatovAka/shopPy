let products = [];

async function loadProducts() {
    const response = await fetch("/list");
    products = await response.json();

    showProducts(products);
}

function showProducts(list) {
    const grid = document.getElementById("productsGrid");
    grid.innerHTML = "";

    list.forEach(p => {
        const img = "/images/" + (p.image || "no_img.png");

        const card = document.createElement("div");
        card.className = "card";
        card.innerHTML = `
            <img src="${img}">
            <h3>${p.name}</h3>
            <p>${p.price} ₸</p>
        `;
        card.onclick = () => showModal(p, img);
        grid.appendChild(card);
    });
}

document.getElementById("searchInput")?.addEventListener("input", (e) => {
    const text = e.target.value.toLowerCase();
    const filtered = products.filter(p =>
        p.name.toLowerCase().includes(text) ||
        p.maker.toLowerCase().includes(text)
    );
    showProducts(filtered);
});

function showModal(product, img) {
    document.getElementById("modalImg").src = img;
    document.getElementById("modalName").textContent = product.name;
    document.getElementById("modalMaker").textContent = product.maker;
    document.getElementById("modalDate").textContent = product.date;
    document.getElementById("modalWeight").textContent = product.weight;
    document.getElementById("modalPrice").textContent = product.price;

    document.getElementById("modalBg").style.display = "flex";

    document.getElementById("removeBtn").onclick = async function() {
        if (!confirm(`Удалить "${product.name}"?`)) return;

        await fetch("/remove", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({id: product.id})
        });

        document.getElementById("modalBg").style.display = "none";
        loadProducts();
    };
}

document.getElementById("closeBtn")?.addEventListener("click", () => {
    document.getElementById("modalBg").style.display = "none";
});

window.onload = loadProducts;

function initAddForm() {
    const form = document.getElementById("addForm");
    if (!form) return;

    async function uploadImage() {
        const fileInput = document.getElementById("image");
        if (fileInput.files.length === 0) return null;

        let formData = new FormData();
        formData.append("file", fileInput.files[0]);

        const r = await fetch("/upload_image", {method: "POST", body: formData});
        return (await r.json()).filename;
    }

    form.onsubmit = async function(e) {
        e.preventDefault();

        let filename = await uploadImage();

        const product = {
            name: document.getElementById("name").value,
            maker: document.getElementById("maker").value,
            date: document.getElementById("date").value,
            weight: document.getElementById("weight").value,
            price: document.getElementById("price").value,
            image: filename
        };

        await fetch("/add", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(product)
        });

        window.location.href = "/products.html";
    };
}

initAddForm();
