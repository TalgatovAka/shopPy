async function loadProducts() {
    const search = document.getElementById('search').value;
    const res = await fetch(`/api/products?search=${encodeURIComponent(search)}`);
    const products = await res.json();

    const container = document.getElementById('products');
    container.innerHTML = '';

    if (products.length === 0) {
        container.innerHTML = '<p>Товары не найдены</p>';
        return;
    }

    products.forEach(p => {
        const div = document.createElement('div');
        div.className = 'product';
        div.innerHTML = `
            ${p.photo ? `<img src="${p.photo}" alt="Фото">` : ''}
            <h2>${p.name}</h2>
            <p>Производитель: ${p.manufacturer}</p>
            <p>Дата выпуска: ${p.release_date}</p>
            <p>Вес: ${p.weight} кг</p>
            <p>Цена: ${p.price}₸</p>
            <button onclick="deleteProduct(${p.id})">Удалить</button>
        `;
        container.appendChild(div);
    });
}

async function deleteProduct(id) {
    if (!confirm('Удалить этот товар?')) return;
    const res = await fetch(`/api/products/${id}`, { method: 'DELETE' });
    if (res.ok) loadProducts();
    else alert('Ошибка удаления');
}

window.onload = loadProducts;
